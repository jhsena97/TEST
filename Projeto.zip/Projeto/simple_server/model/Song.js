const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Song = new Schema({
  title: {
    type: String
  },
  songwriter: {
    type: String
  },
  lyrics: {
    type: String
  },
  my_image: {
    type: String
  }
},{
    collection: 'Song'
});

module.exports = mongoose.model('Song', Song);
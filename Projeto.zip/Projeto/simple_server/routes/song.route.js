const express = require('express');
const app = express();
const songRoutes = express.Router();

let Song = require('../model/Song');

// api to add song
songRoutes.route('/add').post(function (req, res) {
    let song = new Song(req.body);
    song.save()
        .then(song => {
            res.status(200).json({ 'status': 'success', 'mssg': 'song added successfully' });
        })
        .catch(err => {
            res.status(409).send({ 'status': 'failure', 'mssg': 'unable to save to database' });
        });
});

// api to get songs
songRoutes.route('/').get(function (req, res) {
    Song.find(function (err, songs) {
        if (err) {
            res.status(400).send({ 'status': 'failure', 'mssg': 'Something went wrong' });
        }
        else {
            res.status(200).json({ 'status': 'success', 'songs': songs });
        }
    });
});

// api to get song
songRoutes.route('/song/:id').get(function (req, res) {
    let id = req.params.id;
    Song.findById(id, function (err, song) {
        if (err) {
            res.status(400).send({ 'status': 'failure', 'mssg': 'Something went wrong' });
        }
        else {
            res.status(200).json({ 'status': 'success', 'song': song });
        }
    });
});

// api to update route
songRoutes.route('/update/:id').put(function (req, res) {
    Song.findById(req.params.id, function (err, song) {
        if (!song) {
            res.status(400).send({ 'status': 'failure', 'mssg': 'Unable to find data' });
        } else {
            song.name = req.body.name;
            song.cnpj = req.body.cnpj;
            song.area = req.body.area;

            song.save().then(business => {
                res.status(200).json({ 'status': 'success', 'mssg': 'Update complete' });
            })
        }
    });
});

// api for delete
songRoutes.route('/delete/:id').delete(function (req, res) {
    Song.findByIdAndRemove({ _id: req.params.id }, function (err,) {
        if (err) {
            res.status(400).send({ 'status': 'failure', 'mssg': 'Something went wrong' });
        }
        else {
            res.status(200).json({ 'status': 'success', 'mssg': 'Delete successfully' });
        }
    });
});

module.exports = songRoutes;